module.exports = {
    mongoURL: 'mongodb+srv://admin:projeto3@cluster0.220ie.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    //mongoURL: 'mongodb://127.0.0.1:27017',
    dbName: 'projeto3'
};
